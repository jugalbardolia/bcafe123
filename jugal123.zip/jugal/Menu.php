<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Document</title>
    <link rel="stylesheet" href="./bootstrap-5.3.0-JS and CSS/css/bootstrap.min.css">
    <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
    
</head>
<body>

<?php
    require 'navbar.php';
    $servername="localhost";
    $username="root";
    $password="";
    $database="dbcafe";
  
    $conn =mysqli_connect($servername, $username, $password, $database);
    if(!$conn){
      die("sorry".mysqli_connect_error());
    }
    else{
       
      
    }
?>

<section>
  <div class="container my-4">
    <h2 class="text-center my-4">FOOD MENU ITEMS</h2>
    <img src="./upload/" alt="">
    <div class="row my-4">

<?php 
         $sql = "SELECT * FROM `additems`"; 
         $result = mysqli_query($conn, $sql);
         while($row = mysqli_fetch_assoc($result)){
          
          $name = $row['name'];
          
          $desc = $row['description'];
          
          echo '<div class="col-md-4 my-2">
         
            <div class="card" style="width: 25rem;">
          <img width="250px" height="250px" src="./upload/'.$row["product_image"].'" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">'.$name.'</h5>
            <p class="card-text">'.$desc.'</p>
            <a href="plz.php"; class="btn btn-primary">Add to cart</a>
           
          </div>
        </div>
            </div>';
         }
          ?>
      </section>
        <br>
   
   
    <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
</body>

  
  <section>
    <div class="b-example-divider" > <footer class="py-3 my-4">
      <ul class="nav justify-content-center border-bottom pb-3 mb-3">
        <li class="nav-item"><a href="./p1.php" class="nav-link px-2 text-body-secondary">Home</a></li>
        <li class="nav-item"><a href="#" class="nav-link px-2 text-body-secondary">Features</a></li>
        <li class="nav-item"><a href="./contact.php" class="nav-link px-2 text-body-secondary">Contact us</a></li>
        <li class="nav-item"><a href="#" class="nav-link px-2 text-body-secondary">FAQs</a></li>
        <li class="nav-item"><a href="./about.php" class="nav-link px-2 text-body-secondary">About us</a></li>
      </ul>
      <p class="text-center text-body-secondary">© 2023 Company, Inc</p>
    </footer></div>
   
  </section>