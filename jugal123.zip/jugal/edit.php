<?php
 
    $servername="localhost";
    $username="root";
    $password="";
    $database="dbcafe";
  
    $conn =mysqli_connect($servername, $username, $password, $database);
    if(!$conn){
      die("sorry".mysqli_connect_error());
    }
    else{
       
      
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./bootstrap-5.3.0-JS and CSS/css/bootstrap.min.css">
    <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
    <style>
        .product_img{
            width: 100px;
            object-fit: contain;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="admin.php">ADMIN PRO PANEL</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="add.php">ADD MENU ITEMS</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="adreview.php">Reviews</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="edit.php">Edit items</a>
        </li>
      </ul>
      <button type="button" class="btn btn-danger"><a href="login.php">Sign out</a></button>
    </div>
  </div>
</nav>
<br>

<div class="container text-center">
  <div class="row">
    <div class="col">
    <section>
    <table class="table">
  <thead>
    <tr>
      <th scope="col">Sr no</th>
      <th scope="col">Name</th>
      <th scope="col">Description</th>
      <th scope="col">Product Image</th>
      <th scope="col">Edit</th>
      <th scope="col">Delete</th>
    </tr>
  </thead>
  <tbody>
  <?php
            $sql="select * from additems";
            $res=mysqli_query($conn,$sql);
            $number=0;
            while($row=mysqli_fetch_assoc($res)){
                $product_id=$row['id'];
                $product_name=$row['name'];
                $product_desc=$row['description'];
                $product_image=$row['product_image'];
                $number++;
                ?>
                <tr class='text-center'>
                <td><?php echo $number; ?></td>
                <td><?php echo $product_name;?></td>
                <td><?php echo $product_desc;?></td>
                <td><img src='./upload/<?php echo $product_image;?>' class='product_img' /></td>
                <td><a href='update.php?edit_products=<?php echo $product_id;?>' class='text-light'><button class='btn btn-primary'>Edit</button></a></td>
                <td><a href='delete.php?delete_product=<?php echo $product_id;?>' class='text-light'><button class='btn btn-danger'>Delete</button></a></td>
            </tr>
            <?php
            }    
        ?>
  </tbody>
</table>
</section>
    </div>

</body>
</html>