<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Document</title>
    <link rel="stylesheet" href="./bootstrap-5.3.0-JS and CSS/css/bootstrap.min.css">
    <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
    
</head>
<body>


<?php
  require 'navbar.php';
?>
<?php
$servername="localhost";
    $username="root";
    $password="";
    $database="dbcafe";
  
    $conn =mysqli_connect($servername, $username, $password, $database);
    if(!$conn){
      die("sorry".mysqli_connect_error());
    }
    else{
       
       
      
    }
?>

  
  <section>
    <div id="carouselExampleCaptions" class="carousel slide">
      <div class="carousel-indicators">
       
       
      </div>
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="./computer-2242263_1280.jpg" class="d-block w-100"style="height:650px " style="width: auto;" alt="...">
          <div class="carousel-caption d-none d-md-block">
            <h5>COFFEE</h5>
            <h4 style="color: black; ">A TASTE YOU WILL REMEMBER.</h4>
          </div>
        </div>
       
      </div>
      
    </div>
  </section>

  <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./bootstrap-5.3.0-JS and CSS/css/bootstrap.min.css">
    <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
</head>
<body>
  <br>
  
   
    
  
   <section>
    <div class="b-example-divider" > <footer class="py-3 my-4">
      <ul class="nav justify-content-center border-bottom pb-3 mb-3">
        <li class="nav-item"><a href="./p1.php" class="nav-link px-2 text-body-secondary">Home</a></li>
        <li class="nav-item"><a href="./Menu.php" class="nav-link px-2 text-body-secondary">Menu</a></li>
        <li class="nav-item"><a href="./contact.php" class="nav-link px-2 text-body-secondary">Contact us</a></li>
        <li class="nav-item"><a href="./Feedback.php" class="nav-link px-2 text-body-secondary">Feedbacks</a></li>
        <li class="nav-item"><a href="./about.php" class="nav-link px-2 text-body-secondary">About us</a></li>
      </ul>
      <p class="text-center text-body-secondary">© 2023 Company, Inc</p>
    </footer></div>
   
  </section> 

  <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
</body>
</html>



