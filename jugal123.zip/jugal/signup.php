<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    
    <title>Document</title>
    <link rel="stylesheet" href="./bootstrap-5.3.0-JS and CSS/css/bootstrap.min.css">
    <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
</head>
<body style="background-color: aqua;">
    <header>
      <?php
      require 'navbar.php';
    ?>
    </header>
    <!-- login -->
    <main class="form-signin w-100 m-auto">
      <form style="width: 25%; margin-top: 160px; margin-left: 700px;">
        <!-- <img class="mb-4" src="logo.png" alt="" width="100" height="100 ">
        <h1 class="h3 mb-3 fw-normal bg-dark " > Please sign in to the bungalow cafe</h1> -->
        <img src="logo.png" alt="Logo" width="120" height="120" style="margin-left: 150px;"> <br> <br> <h3 style="font-size: xx-large;">THE BUNGALOW CAFE SIGNUP</h3>
        <br>
        
        <div class="form-floating">
            <input type="name" class="form-control" id="floatingInput" placeholder="name" required>
            <label for="floatingInput">Name</label>
          </div>
        <div class="form-floating">
          <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com"required>
          <label for="floatingInput">Email address</label>
        </div>
        <div class="form-floating">
            <input type="number" class="form-control" id="floatingInput" placeholder="contact no"required>
            <label for="floatingInput">Mobile No</label>
          </div>
        <div class="form-floating">
          <input type="password" class="form-control" id="floatingPassword" placeholder="Password"required>
          <label for="floatingPassword">Password</label>
        </div>
        <div class="form-floating">
            <input type="password" class="form-control" id="floatingPassword" placeholder=" Confirm Password"required>
            <label for="floatingPassword">Confirm Password</label>
          </div>
       <br>
        <button class="btn btn-primary w-100 py-2" type="submit">Sign up</button>
        <!-- <p class="mt-5 mb-3 text-body-secondary">© 2017–2023</p> -->
      </form>
    </main>
    <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
</body>
</html>