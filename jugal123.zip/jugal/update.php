<?php
 
    $servername="localhost";
    $username="root";
    $password="";
    $database="dbcafe";
  
    $conn =mysqli_connect($servername, $username, $password, $database);
    if(!$conn){
      die("sorry".mysqli_connect_error());
    }
    else{
       
      
    }
?>

<?php
if(isset($_GET['edit_products'])){
    $edit_id=$_GET['edit_products'];
    $sql="select * from additems where id=$edit_id";
    $res=mysqli_query($conn,$sql);
    $row=mysqli_fetch_assoc($res);
    $product_name=$row['name'];
    $product_descripition=$row['description'];
    $product_image=$row['product_image'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./bootstrap-5.3.0-JS and CSS/css/bootstrap.min.css">
    <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
    <style>
        .product_img{
            width: 100px;
            object-fit: contain;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center">Edit Product</h1>
    <form action="" method="post" enctype="multipart/form-data">
        <div class="form-outline w-50 m-auto mb-4">
            <label for="product_name" class="form-label">Product Name</label>
            <input type="text" id="product_name" value="<?php echo $product_name;?>" name="name" class="form-control">
        </div>
        <div class="form-outline w-50 m-auto mb-4">
            <label for="product_descripition" class="form-label">Product Description</label>
            <input type="text" id="product_descripition" value="<?php echo $product_descripition;?>" name="description" class="form-control">
        </div>
        
        <div class="form-outline w-50 m-auto mb-4">
            <label for="product_image1" class="form-label">Product Image1</label>
            <div class="d-flex">
            <input type="file" id="product_image" name="product_image" class="form-control w-90 m-auto" >
            <img src="./upload/<?php echo $product_image;?>" alt="" class="product_img">
            </div>
        </div>
        <div class="w-50 m-auto">
            <input type="submit" name="editproduct" value="Update Product" class="btn btn-primary px-3 mb-3">
        </div>
    </form>
</div>
</body>
</html>

<?php 
if(isset($_POST['editproduct'])){
    $product_name=$row['name'];
    $product_descripition=$row['description'];
    $product_image=$row['product_image'];

    $product_image=$_FILES['product_image']['name'];

    $temp_image=$_FILES['product_image']['tmp_name'];

        move_uploaded_file($temp_image,"./upload/$product_image");

        $update_product="update additems set name='$product_name',
        description='$product_descripition,product_image='$product_image', where id=$edit_id";

        $res_update=mysqli_query($conn,$update_product);
        if($res_update){
            echo "<script>alert('Product Updated Successfully')</script>";
            // echo "<script>window.open('./index.php?view_product','_self')</script>";
        }
    
}

?>