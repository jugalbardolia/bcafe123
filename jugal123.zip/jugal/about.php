<?php
  require 'navbar.php';
?>

<br>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./bootstrap-5.3.0-JS and CSS/css/bootstrap.min.css">
    <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div class="container text-center">
  <div class="row">
    <div class="col">
    <div class="card" style="width: 25rem;">
  <img src="abt.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">About Us</h5>
    <p class="card-text">You will receive an infographic guide in your email once you are able to place your order. Kindly go through this and wait until we are able to confirm your order and pick up time.

Cutoff for payment is 4PM of the day before your pick up date. You may pay once you receive payment details up until 4PM of the day before your order. Unpaid orders will automatically be cancelled..</p>
    <a href="./p1.php" class="btn btn-primary">Go Home</a>
  </div>
</div>
    </div>
    <br>
    <br>
    <br>

    <div class="col">
      
    </div>
    <div class="col">
    <br>
        <br>
        <br>
        <br>
    <div class="accordion" id="accordionExample">
  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
      

        About Cafe 
      </button>
    </h2>
    <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>We are focused on giving a satisfactory user experience and creating spaces which connect with the local culture of any location we establish at. As a brand, we deeply understand and value the connect our customers need to feel and thus, each of our cafes are community spaces, socializing spots that are inspired </strong> 
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
        About food
      </button>
    </h2>
    <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>A café is a type of restaurant which typically serves coffee and tea, in addition to light refreshments such as baked goods or snacks. The term "café" comes from the French word meaning "coffee".</strong>
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
        About service
      </button>
    </h2>
    <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>This service normally exists in industrial canteens, colleges, hospitals or hotel staff cafeterias. To facilitate quick service, the menu is fixed and display on large menu boards with each item priced separately. .</strong>
      </div>
    </div>
  </div>
</div>
    </div>
  </div>
</div>
<script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
</body>
</html>