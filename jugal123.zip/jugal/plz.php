<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>plz login to add to cart</h1>
    <a href="login.php"; class="btn btn-primary">Login</a>
</body>
</html>