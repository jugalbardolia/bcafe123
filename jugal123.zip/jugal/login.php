

<?php
    require 'navbar.php';
    $servername="localhost";
    $username="root";
    $password="";
    $database="dbcafe";
  
    $conn =mysqli_connect($servername, $username, $password, $database);
    if(!$conn){
      die("sorry".mysqli_connect_error());
    }
    else{
       
      
    }
?>

<?php

// if(isset($_POST['insert']))
// {
//   $uname=$_POST['email'];
//   $pass=$_POST['pass'];

//   $q="INSERT INTO `login` (`email`, `password`) VALUES ('$uname', '$pass')";
//   $res=mysqli_query($conn,$q);
//   if($res)
//   {
//     echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
//           <strong>Success!</strong> Your login has been success!
          
           
          
//         </div>';
//   }
//   else {
//     echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
//           <strong>Success!</strong> Your login has been failed!
          
           
          
//         </div>';
//   }
    
   
  
 
// }

if(isset($_POST["insert"])){
  $email = $_POST['email'];
  $passwrd = $_POST['pass'];
  if($email=="admin@gmail.com" && $passwrd=="admin123")
  {
    header("location:http://localhost/jugal/admin.php");
  }
  $result = mysqli_query($conn , "select * from signin where email = '$email'");
  $row = mysqli_fetch_assoc($result);
  if(mysqli_num_rows($result) > 0){
      if($passwrd == $row["password"]){
          // 
          echo "sucees";
          print_r(header("location:http://localhost/jugal/p1.php"));
      }
      
      else{
          echo "<script> alert('wrong Password'); </script>";
      }
  }
  else{
      echo "<script> alert('User Not Registered'); </script>";
  }
}
?>

  <!-- login -->
  <main class="form-signin w-100 m-auto"  >
    <form method="post" style="width: 25%; margin-top: 181px; margin-left: 700px;">
      <!-- <img class="mb-4" src="logo.png" alt="" width="100" height="100 ">
      <h1 class="h3 mb-3 fw-normal bg-dark " > Please sign in to the bungalow cafe</h1> -->
      <img src="logo.png" alt="Logo" width="120" height="120" style="margin-left: 150px;"> <br> <br> <h3 style="font-size: xx-large;">THE BUNGALOW CAFE LOGIN</h3>
      <br>
      
  
      <div class="form-floating">
        <input type="email" class="form-control" id="floatingInput" name="email" placeholder="name@example.com" required>
        <label for="floatingInput">Email address</label>
      </div>
      <div class="form-floating">
        <input type="password" class="form-control" id="floatingPassword" name="pass" placeholder="Password" required>
        <label for="floatingPassword">Password</label>
      </div>
      <br>
      
      <button class="btn btn-primary w-100 py-2" name="insert" type="submit">Sign in</button>
      <!-- <p class="mt-5 mb-3 text-body-secondary">© 2017–2023</p> -->
    </form>
  </main>
 