<?php
    include 'navbar.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./bootstrap-5.3.0-JS and CSS/css/bootstrap.min.css">
    <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <section>
        <br>
    <div class="container text-center">
  <div class="row">
    <div class="col">
    <div class="card" style="width: 25rem;">
  <img src="p1.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Italian Pasta</h5>
    <p class="card-text">Delicious Italian cheese pasta.</p>
    <a href="#" class="btn btn-primary">Add to cart</a>
  </div>
</div>
    </div>
    <div class="col">
    <div class="card" style="width: 23rem;">
  <img src="p2.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Brown pasta</h5>
    <p class="card-text">Diet gym pasta.</p>
    <a href="#" class="btn btn-primary">Add to cart</a>
  </div>
</div>
    </div>
    <div class="col">
    <div class="card" style="width: 25rem;">
  <img src="p3.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Spaghett Pasta</h5>
    <p class="card-text">Spaghetti pasta with cheese.</p>
    <a href="#" class="btn btn-primary">Add to cart</a>
  </div>
</div>
    </div>
  </div>
</div>
    </section>
    <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
</body>
</html>