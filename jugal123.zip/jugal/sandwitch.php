<?php
    include 'navbar.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./bootstrap-5.3.0-JS and CSS/css/bootstrap.min.css">
    <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <section>
        <br>
    <div class="container text-center">
  <div class="row">
    <div class="col">
    <div class="card" style="width: 25rem;">
  <img src="s1.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Club Sandwich</h5>
    <p class="card-text">Delicious Club cheese sandwich.</p>
    <a href="#" class="btn btn-primary">Add to cart</a>
  </div>
</div>
    </div>
    <div class="col">
    <div class="card" style="width: 24rem;">
  <img src="s2.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Diet Sandwich</h5>
    <p class="card-text">Diet Gym sandwich.</p>
    <a href="#" class="btn btn-primary">Add to cart</a>
  </div>
</div>
    </div>
    <div class="col">
    <div class="card" style="width: 26rem;">
  <img src="s3.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Italian sandwich</h5>
    <p class="card-text">Italian sandwich with cheese.</p>
    <a href="#" class="btn btn-primary">Add to cart</a>
  </div>
</div>
    </div>
  </div>
</div>
    </section>
    <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
</body>
</html>