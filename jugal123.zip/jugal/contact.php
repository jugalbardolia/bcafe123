<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    
    <title>Document</title>
    <link rel="stylesheet" href="./bootstrap-5.3.0-JS and CSS/css/bootstrap.min.css">
    <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
    
</head>
<body>
  <header>
    <?php
    require 'navbar.php';
  ?>
  </header>
  <main class="form-signin w-100 m-auto">
    <form style="width: 25%; margin-top: 100px; margin-left: 700px;">
      <!-- <img class="mb-4" src="logo.png" alt="" width="100" height="100 ">
      <h1 class="h3 mb-3 fw-normal bg-dark " > Please sign in to the bungalow cafe</h1> -->
      <img src="logo.png" alt="Logo" width="120" height="120" style="margin-left: 150px;"> <br> <br> <h3 style="font-size: xx-large;">THE BUNGALOW CAFE PAGE</h3>
      <br>

      <div class="card" style="width: 18rem; margin-left: 50px;">
        <img src="./hotel-4857711_640.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">CONTACT US</h5>
          <p class="card-text">THE BUNGALOW CAFE </p>
          
            <p class="card-text">AAGAM VIVIANNA VESU SURAT </p>
        </div>
        <ul class="list-group list-group-flush">
          <li class="list-group-item">BGCAFE@GMAIL.COM</li>
          <li class="list-group-item">0261 2233447</li>
          <li class="list-group-item">+91 9876567998</li>
        </ul>
        
      </div>

    <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>

</body>
</html>