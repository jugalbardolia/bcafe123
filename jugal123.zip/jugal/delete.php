<?php
 
    $servername="localhost";
    $username="root";
    $password="";
    $database="dbcafe";
  
    $conn =mysqli_connect($servername, $username, $password, $database);
    if(!$conn){
      die("sorry".mysqli_connect_error());
    }
    else{
       
      
    }
?>
<?php
if(isset($_GET['delete_product'])){
    $delete_product = $_GET['delete_product'];

    $sql="delete from additems where id = $delete_product";
    $res=mysqli_query($conn,$sql);
    if ($res) {
        echo "<script>alert('Category Deleted Successfully')</script>";
        echo "<script>window.open('edit.php','_self')</script>";
    }
}



?>