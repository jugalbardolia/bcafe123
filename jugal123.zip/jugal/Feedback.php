<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    
    <title>Document</title>
    <link rel="stylesheet" href="./bootstrap-5.3.0-JS and CSS/css/bootstrap.min.css">
    <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
</head>
<body>
  <header>
    <?php
  require 'navbar.php';
?>
  </header>
  
  <?php
$servername="localhost";
    $username="root";
    $password="";
    $database="dbcafe";
  
    $conn =mysqli_connect($servername, $username, $password, $database);
    if(!$conn){
      die("sorry".mysqli_connect_error());
    }
    else{
       
       
      
    }
?>

<?php
if(isset($_POST["insert"])){
    $itemname = $_POST["itemname"];
    $feedback = $_POST["feedback"];

    // $sp = md5($password);
   
   
     $q= "insert into feedback (itemname,feedback) values('$itemname','$feedback')";
            $res=mysqli_query($conn,$q);
  if($res)
  {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
          <strong>Success!</strong> Your Feedback has been received!
          
           
          
        </div>';
  }
  else {
    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          <strong>Failed!</strong> Your feedback has been failed!
          
           
          
        </div>';
  }
}


?>
 <form method="post" style="width: 25%; margin-top: 100px; margin-left: 700px;">
      <!-- <img class="mb-4" src="logo.png" alt="" width="100" height="100 ">
      <h1 class="h3 mb-3 fw-normal bg-dark " > Please sign in to the bungalow cafe</h1> -->
      <img src="logo.png" alt="Logo" width="120" height="120" style="margin-left: 150px;"> <br> <br> <h3 style="font-size: xx-large;">THE BUNGALOW CAFE FEEDBACK</h3>
      <br>
      
  
      <div class="form-floating">
            <input type="text" name="itemname" class="form-control" id="floatingInput" placeholder="" required>
            <label for="floatingInput">ITEM NAME</label>
          </div>
          <div class="form-floating">
            <input type="text" name="feedback" class="form-control" id="floatingInput" placeholder="" required>
            <label for="floatingInput">ITEM FEEDBACK</label>
          </div>
     
      <br>
      
      <button class="btn btn-primary w-100 py-2" name="insert" type="submit">ADD FEEDBACK</button>
      <!-- <p class="mt-5 mb-3 text-body-secondary">© 2017–2023</p> -->
    </form>
</body>
</html>