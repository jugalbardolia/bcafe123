<?php
    include 'navbar.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./bootstrap-5.3.0-JS and CSS/css/bootstrap.min.css">
    <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <section>
        <br>
    <div class="container text-center">
  <div class="row">
    <div class="col">
    <div class="card" style="width: 23rem;">
  <img src="burger.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">BBQ Burger</h5>
    <p class="card-text">Delicious cheese HamBurger.</p>
    <a href="#" class="btn btn-primary">Add to cart</a>
  </div>
</div>
    </div>
    <div class="col">
    <div class="card" style="width: 24rem;">
  <img src="maharaja.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Maharaja Burger</h5>
    <p class="card-text">Maharaja Burger with cheese burst.</p>
    <a href="#" class="btn btn-primary">Add to cart</a>
  </div>
</div>
    </div>
    <div class="col">
    <div class="card" style="width: 22rem;">
  <img src="tikki.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Allotikki Burger</h5>
    <p class="card-text">Allotikki cheese burger.</p>
    <a href="#" class="btn btn-primary">Add to cart</a>
  </div>
</div>
    </div>
  </div>
</div>
    </section>
    <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
</body>
</html>