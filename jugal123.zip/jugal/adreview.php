<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./bootstrap-5.3.0-JS and CSS/css/bootstrap.min.css">
    <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="admin.php">ADMIN PRO PANEL</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="add.php">ADD MENU ITEMS</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="adreview.php">Reviews</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="edit.php">Edit items</a>
        </li>
        
      </ul>
      <button type="button" class="btn btn-danger"><a href="login.php">Sign out</a></button>
    </div>
  </div>
</nav>

<?php
 
    $servername="localhost";
    $username="root";
    $password="";
    $database="dbcafe";
  
    $conn =mysqli_connect($servername, $username, $password, $database);
    if(!$conn){
      die("sorry".mysqli_connect_error());
    }
    else{
       
      
    }
?>

<section>
  <div class="container my-4">
    <h2 class="text-center my-4">BUNGALOW CAFE REVIEWS</h2>
    <div class="row my-4">

<?php 
         $sql = "SELECT * FROM `feedback`"; 
         $result = mysqli_query($conn, $sql);
         while($row = mysqli_fetch_assoc($result)){
          
          $itemname = $row['itemname'];
          
          $desc = $row['feedback'];
          
          echo '<div class="col-md-4 my-2">
         
            <div class="card" style="width: 25rem;">
          
          <div class="card-body">
            <h5 class="card-title">'.$itemname.'</h5>
            <p class="card-text">'.$desc.'</p>
           
           
          </div>
        </div>
            </div>';
         }
          ?>
      </section>