<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./bootstrap-5.3.0-JS and CSS/css/bootstrap.min.css">
    <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="admin.php">ADMIN PRO PANEL</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="add.php">ADD MENU ITEMS</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="adreview.php">Reviews</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="edit.php">Edit items</a>
        </li>
      </ul>
      <button type="button" class="btn btn-danger"><a href="login.php">Sign out</a></button>
    </div>
  </div>
</nav>
<br>
<br>
<h1>WELCOME TO ADMIN PANEL</h1>
</body>
</html>



