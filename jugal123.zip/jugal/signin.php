<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
     <link rel="stylesheet" href="./bootstrap-5.3.0-JS and CSS/css/bootstrap.min.css">
    <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    
</body>
</html>

<?php
    require 'navbar.php';
    $servername="localhost";
    $username="root";
    $password="";
    $database="dbcafe";
  
    $conn =mysqli_connect($servername, $username, $password, $database);
    if(!$conn){
      die("sorry".mysqli_connect_error());
    }
    else{
       
      
    }
?>

<?php

// if(isset($_POST['insert']))
// {
//   $uname=$_POST['name'];
//   $uemail=$_POST['email'];
//   $Mobno=$_POST['mobno'];

//   $pass=$_POST['pass'];
//   $cpass=$_POST['cpass'];

  
//   $q="INSERT INTO `signin` (`name`,`email`,`mobno`, `password`,`cpassword`) VALUES ('$uname','$uemail','$Mobno', '$pass','$cpass')";
//   $res=mysqli_query($conn,$q);
  
//   if($res)
//   {
//     echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
//           <strong>Success!</strong> Your Sign up has been success!
          
           
          
//         </div>';
//   }
//   else {
//     echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
//           <strong>Success!</strong> Your Sign up has been failed!
          
           
          
//         </div>';
//   }
    
   
  
 
// }
if(isset($_POST["insert"])){
    $username = $_POST["uname"];
    $email = $_POST["email"];
    $password = $_POST["pass"];
    // $sp = md5($password);
    $confirmpassword = $_POST["cpass"];
    $duplicate = mysqli_query($conn, "select * from signin where email = '$email' or username = '$username'");
    if(mysqli_num_rows($duplicate) > 0){
        echo "<script> alert('User Already Exist'); </script>";
    }
    else{
        if($password == $confirmpassword){
            $q= "insert into signin (username,email,password) values('$username','$email','$password')";
            $res=mysqli_query($conn,$q);
  if($res)
  {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
          <strong>Success!</strong> Your login has been success!
          
           
          
        </div>';
  }
  else {
    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          <strong>Failed!</strong> Your login has been failed!
          
           
          
        </div>';
  }
}}
}

?>

  <!-- login -->
  <main class="form-signin w-100 m-auto"  >
  <form method="post" style="width: 25%; margin-top: 160px; margin-left: 700px;">
      <!-- <img class="mb-4" src="logo.png" alt="" width="100" height="100 ">
      <h1 class="h3 mb-3 fw-normal bg-dark " > Please sign in to the bungalow cafe</h1> -->
      <img src="logo.png" alt="Logo" width="120" height="120" style="margin-left: 150px;"> <br> <br> <h3 style="font-size: xx-large;">THE BUNGALOW CAFE SIGNUP</h3>
      <br>
      
  
      <div class="form-floating">
            <input type="text" name="uname" class="form-control" id="floatingInput" placeholder="username" required>
            <label for="floatingInput">Username</label>
          </div>
      <div class="form-floating">
        <input type="email" class="form-control" id="floatingInput" name="email" placeholder="name@example.com" required>
        <label for="floatingInput">Email address</label>
      </div>
     
      <div class="form-floating">
        <input type="password" class="form-control" id="floatingPassword" name="pass" placeholder="Password" required>
        <label for="floatingPassword">Password</label>
      </div>
      <div class="form-floating">
            <input type="password" name="cpass" class="form-control" id="floatingPassword" placeholder=" Confirm Password"required>
            <label for="floatingPassword">Confirm Password</label>
          </div>
      <br>
      
      <button class="btn btn-primary w-100 py-2" name="insert" type="submit">Sign in</button>
      <!-- <p class="mt-5 mb-3 text-body-secondary">© 2017–2023</p> -->
    </form>
  </main>
  <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
</body>
</html>